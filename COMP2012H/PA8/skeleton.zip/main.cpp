#include "GameEngine.h"

using namespace std;

int main()
{
    GameEngine ge;
    ge.run();
    return 0;
}