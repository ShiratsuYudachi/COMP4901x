#include "Monster.h"
#include <cmath>

// write your code here
